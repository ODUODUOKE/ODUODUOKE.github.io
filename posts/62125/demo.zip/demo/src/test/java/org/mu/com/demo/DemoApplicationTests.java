package org.mu.com.demo;

import jakarta.annotation.Resource;
import org.junit.jupiter.api.Test;
import org.mu.com.demo.dao.DemoMapper;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class DemoApplicationTests {

	@Resource
	private DemoMapper demoMapper;

	@Test
	void contextLoads() {

		demoMapper.addTest("test");

	}

}
