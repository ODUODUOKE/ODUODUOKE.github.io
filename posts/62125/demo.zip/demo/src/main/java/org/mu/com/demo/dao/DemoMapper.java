package org.mu.com.demo.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DemoMapper {

    Integer addTest(
            String value
    );

}
