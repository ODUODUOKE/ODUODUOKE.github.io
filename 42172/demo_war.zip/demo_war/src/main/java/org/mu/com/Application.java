package org.mu.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
public class Application extends SpringBootServletInitializer {

    /**
     * spring-boot启动
     * 内嵌tomcat容器中启动,直接main运行当前方法或者maven_springboot插件run方法
     * */
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    /**
     * springboot项目部署外部tomcat容器,重写当前configure方法
     * */
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(Application.class);
    }

}
