package org.mu.com.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/index")
public class IndexController {

    @RequestMapping("/sayHi")
    public String sayHi(){
        return "Say Hi !";
    }

}
