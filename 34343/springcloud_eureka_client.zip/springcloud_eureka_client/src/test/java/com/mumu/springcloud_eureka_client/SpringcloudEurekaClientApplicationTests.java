package com.mumu.springcloud_eureka_client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudEurekaClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
