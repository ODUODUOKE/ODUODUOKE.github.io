package com.mumu.springcloud_eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudEurekaApplicationTests {

    @Test
    void contextLoads() {
    }

}
